<?php

  use Illuminate\Database\Eloquent\Model as Model;

  class Setting extends Model{


  }