<?php

return array (
	'host'    => '127.0.0.1',
	'port'    => 80,
	'indexes' => array (
		'search_index' => array ( 'table' => 'posts', 'column' => 'search_index', 'model' => 'Post' ),
	)
);
