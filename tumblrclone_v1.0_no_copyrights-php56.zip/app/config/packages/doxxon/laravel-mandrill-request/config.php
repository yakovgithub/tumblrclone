<?php

return array(

    /*
    |--------------------------------------------------------------------------
    | Mandrill API key
    |--------------------------------------------------------------------------
    |
    | Set api keys from: https://mandrillapp.com/settings/index
    |
    */
	'api_key' => 'niLQK5PGRAVaSGzO63-DUw',

);
