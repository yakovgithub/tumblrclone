<!DOCTYPE html>
<html lang="en-US">
	<head>
		<meta charset="utf-8">
	</head>
	<body>
		<h2>Activate Your Account</h2>

		<div>
			<p>Please click the link below to activate your account</p>
			<p><a class="btn btn-lg btn-primary" href="<?php echo $link;?>">Activate</a></p>
		</div>
	</body>
</html>
